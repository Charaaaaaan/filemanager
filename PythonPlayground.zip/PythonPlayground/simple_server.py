#!/usr/bin/env python3
"""
Simple HTTP Server for File Organizer with Stripe Integration
"""

import os
import json
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from stripe_payment import StripePayment, generate_payment_page
from database_manager import DatabaseManager

class FileOrganizerHandler(BaseHTTPRequestHandler):
    """HTTP request handler for File Organizer payment system"""
    
    def __init__(self, *args, **kwargs):
        self.stripe_payment = StripePayment()
        self.db = DatabaseManager()
        super().__init__(*args, **kwargs)
    
    def do_GET(self):
        """Handle GET requests"""
        if self.path == '/':
            self.send_homepage()
        elif self.path == '/payment/basic':
            self.send_payment_page('basic')
        elif self.path == '/payment/pro':
            self.send_payment_page('pro')
        elif self.path.startswith('/payment.html'):
            self.send_file('payment.html', 'text/html')
        elif self.path == '/webhook':
            self.handle_webhook()
        elif self.path == '/admin/stats':
            self.send_admin_stats()
        else:
            self.send_404()
    
    def do_POST(self):
        """Handle POST requests"""
        if self.path == '/create-payment-intent':
            self.handle_payment_intent()
        elif self.path == '/webhook':
            self.handle_webhook()
        elif self.path == '/complete-payment':
            self.handle_payment_completion()
        else:
            self.send_404()
    
    def send_homepage(self):
        """Send the main homepage with pricing"""
        html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Organizer - Premium Plans</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            color: white;
            margin-bottom: 40px;
        }
        
        .header h1 {
            font-size: 3rem;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .pricing-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin: 40px 0;
        }
        
        .plan-card {
            background: white;
            border-radius: 15px;
            padding: 40px 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        
        .plan-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        
        .plan-name {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        
        .plan-price {
            font-size: 3rem;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 20px;
        }
        
        .features {
            list-style: none;
            margin: 20px 0;
            text-align: left;
            padding: 0;
        }
        
        .features li {
            padding: 8px 0;
            position: relative;
            padding-left: 25px;
        }
        
        .features li::before {
            content: "✓";
            position: absolute;
            left: 0;
            color: #667eea;
            font-weight: bold;
        }
        
        .btn {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            width: 100%;
            margin-top: 20px;
            transition: all 0.3s ease;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .demo-section {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin: 40px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>File Organizer</h1>
            <p>Professional file analysis and organization planning tool</p>
        </div>
        
        <div class="pricing-grid">
            <div class="plan-card">
                <div class="plan-name">Basic Plan</div>
                <div class="plan-price">$9.99</div>
                <ul class="features">
                    <li>Unlimited directory scans</li>
                    <li>Advanced file statistics</li>
                    <li>Custom organization rules</li>
                    <li>Export analysis reports</li>
                </ul>
                <a href="/payment/basic" class="btn">Get Basic Plan</a>
            </div>
            
            <div class="plan-card" style="border: 3px solid #667eea; transform: scale(1.05);">
                <div class="plan-name">Pro Plan</div>
                <div class="plan-price">$19.99</div>
                <ul class="features">
                    <li>All Basic features</li>
                    <li>Bulk operations</li>
                    <li>Advanced filtering</li>
                    <li>Priority support</li>
                    <li>Custom file type definitions</li>
                </ul>
                <a href="/payment/pro" class="btn">Get Pro Plan</a>
            </div>
        </div>
        
        <div class="demo-section">
            <h2>Command Line Tool Demo</h2>
            <p>Try the free version of File Organizer:</p>
            <pre style="background: #f8f9fa; padding: 20px; border-radius: 10px; text-align: left; overflow-x: auto;">
python file_organizer.py scan /path/to/directory    # Scan and analyze files
python file_organizer.py organize /source /target   # Show organization plan
python file_organizer.py config                     # View configuration
            </pre>
        </div>
    </div>
</body>
</html>
        """
        
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(html_content.encode())
    
    def send_payment_page(self, plan_type):
        """Send payment page for specified plan"""
        plans = {
            'basic': {'name': 'Basic Plan', 'amount': 999, 'description': 'Essential file organization features'},
            'pro': {'name': 'Pro Plan', 'amount': 1999, 'description': 'Complete file organization suite'}
        }
        
        if plan_type not in plans:
            self.send_404()
            return
        
        plan = plans[plan_type]
        html_content = generate_payment_page(plan['name'], plan['amount'], plan['description'])
        
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(html_content.encode())
    
    def handle_payment_intent(self):
        """Handle payment intent creation"""
        try:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            
            # Create payment intent
            result = self.stripe_payment.create_payment_intent(
                amount=data.get('amount', 1999),
                currency=data.get('currency', 'usd'),
                description=data.get('description', 'File Organizer Premium')
            )
            
            if result:
                response_data = {'client_secret': result['client_secret']}
                self.send_json_response(response_data)
            else:
                self.send_error_response('Failed to create payment intent')
                
        except Exception as e:
            self.send_error_response(f'Error processing request: {str(e)}')
    
    def handle_payment_completion(self):
        """Handle payment completion and save to database"""
        try:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            
            payment_intent_id = data.get('payment_intent_id')
            customer_email = data.get('customer_email')
            plan_type = data.get('plan_type', 'basic')
            
            if not payment_intent_id or not customer_email:
                self.send_error_response('Missing required payment information')
                return
            
            # Verify payment with Stripe
            payment_result = self.stripe_payment.retrieve_payment_intent(payment_intent_id)
            
            if payment_result and payment_result.get('status') == 'succeeded':
                # Add user to database
                user_id = self.db.add_user(customer_email)
                
                # Add subscription
                amount = payment_result.get('amount', 0)
                subscription_id = self.db.add_subscription(
                    user_id, plan_type, payment_intent_id, amount
                )
                
                if subscription_id:
                    # Log the purchase
                    self.db.log_usage(customer_email, 'subscription_purchased', {
                        'plan_type': plan_type,
                        'amount': amount,
                        'payment_intent_id': payment_intent_id
                    })
                    
                    response_data = {
                        'success': True,
                        'message': 'Premium features activated!',
                        'plan_type': plan_type
                    }
                    self.send_json_response(response_data)
                else:
                    self.send_error_response('Payment already processed')
            else:
                self.send_error_response('Payment verification failed')
                
        except Exception as e:
            self.send_error_response(f'Error completing payment: {str(e)}')
    
    def handle_webhook(self):
        """Handle Stripe webhooks"""
        try:
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            
            # In production, verify webhook signature here
            event_data = json.loads(post_data.decode('utf-8'))
            
            if event_data.get('type') == 'payment_intent.succeeded':
                payment_intent = event_data['data']['object']
                print(f"Webhook: Payment succeeded for {payment_intent['id']}")
            
            self.send_json_response({'received': True})
            
        except Exception as e:
            self.send_error_response(f'Webhook error: {str(e)}')
    
    def send_admin_stats(self):
        """Send admin statistics page"""
        try:
            stats = self.db.get_subscription_stats()
            
            html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>File Organizer - Admin Stats</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .stat-card {{
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .stat-number {{
            font-size: 2rem;
            font-weight: bold;
            color: #667eea;
        }}
    </style>
</head>
<body>
    <h1>File Organizer - Admin Dashboard</h1>
    
    <div class="stat-card">
        <h3>Total Users</h3>
        <div class="stat-number">{stats['total_users']}</div>
    </div>
    
    <div class="stat-card">
        <h3>Active Subscriptions</h3>
        <div class="stat-number">{sum(stats['subscriptions_by_plan'].values())}</div>
        <p>Basic: {stats['subscriptions_by_plan'].get('basic', 0)}</p>
        <p>Pro: {stats['subscriptions_by_plan'].get('pro', 0)}</p>
    </div>
    
    <div class="stat-card">
        <h3>Total Revenue</h3>
        <div class="stat-number">${stats['total_revenue']:.2f}</div>
    </div>
</body>
</html>
            """
            
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(html_content.encode())
            
        except Exception as e:
            self.send_error_response(f'Error loading stats: {str(e)}')
    
    def send_json_response(self, data):
        """Send JSON response"""
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())
    
    def send_error_response(self, message):
        """Send error response"""
        self.send_response(400)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps({'error': message}).encode())
    
    def send_file(self, filename, content_type):
        """Send file response"""
        try:
            with open(filename, 'r') as f:
                content = f.read()
            self.send_response(200)
            self.send_header('Content-type', content_type)
            self.end_headers()
            self.wfile.write(content.encode())
        except FileNotFoundError:
            self.send_404()
    
    def send_404(self):
        """Send 404 response"""
        self.send_response(404)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'<h1>404 - Page Not Found</h1>')
    
    def log_message(self, format, *args):
        """Override to reduce console spam"""
        pass

def main():
    """Start the server"""
    port = 5000
    server_address = ('0.0.0.0', port)
    
    print(f"Starting File Organizer Payment Server on port {port}")
    print(f"Visit http://localhost:{port} to view the payment interface")
    print("Press Ctrl+C to stop the server")
    
    httpd = HTTPServer(server_address, FileOrganizerHandler)
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
        httpd.shutdown()

if __name__ == '__main__':
    main()