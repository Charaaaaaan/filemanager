#!/usr/bin/env python3
"""
Simple Stripe Payment Integration for File Organizer
"""

import os
import json
import urllib.request
import urllib.parse
from pathlib import Path

class StripePayment:
    """Simple Stripe payment handler using native Python libraries"""
    
    def __init__(self):
        self.secret_key = os.environ.get('STRIPE_SECRET_KEY')
        self.publishable_key = os.environ.get('STRIPE_PUBLISHABLE_KEY')
        
        if not self.secret_key or not self.publishable_key:
            raise ValueError("Stripe API keys not found in environment variables")
    
    def create_payment_intent(self, amount, currency='usd', description='File Organizer Premium'):
        """Create a payment intent using Stripe API"""
        
        url = 'https://api.stripe.com/v1/payment_intents'
        
        data = {
            'amount': amount,
            'currency': currency,
            'description': description,
            'automatic_payment_methods[enabled]': 'true'
        }
        
        # Encode data for POST request
        encoded_data = urllib.parse.urlencode(data).encode('utf-8')
        
        # Create request with authorization header
        req = urllib.request.Request(url, data=encoded_data, method='POST')
        req.add_header('Authorization', f'Bearer {self.secret_key}')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        
        try:
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                return result
        except Exception as e:
            print(f"Error creating payment intent: {e}")
            return None
    
    def retrieve_payment_intent(self, payment_intent_id):
        """Retrieve payment intent status"""
        
        url = f'https://api.stripe.com/v1/payment_intents/{payment_intent_id}'
        
        req = urllib.request.Request(url)
        req.add_header('Authorization', f'Bearer {self.secret_key}')
        
        try:
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                return result
        except Exception as e:
            print(f"Error retrieving payment intent: {e}")
            return None

def generate_payment_page(plan_name, amount, description):
    """Generate a simple HTML payment page"""
    
    publishable_key = os.environ.get('STRIPE_PUBLISHABLE_KEY')
    
    html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Organizer - {plan_name}</title>
    <script src="https://js.stripe.com/v3/"></script>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        
        .payment-container {{
            background: white;
            border-radius: 15px;
            padding: 40px;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }}
        
        .header {{
            text-align: center;
            margin-bottom: 30px;
        }}
        
        .header h1 {{
            color: #333;
            margin-bottom: 10px;
        }}
        
        .plan-details {{
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            text-align: center;
        }}
        
        .price {{
            font-size: 2.5rem;
            font-weight: bold;
            color: #667eea;
            margin: 10px 0;
        }}
        
        .description {{
            color: #666;
            margin-bottom: 20px;
        }}
        
        #card-element {{
            padding: 15px;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            margin: 20px 0;
        }}
        
        #submit-button {{
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: all 0.3s ease;
        }}
        
        #submit-button:hover {{
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }}
        
        #submit-button:disabled {{
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }}
        
        .error {{
            color: #dc3545;
            margin: 10px 0;
            text-align: center;
        }}
        
        .success {{
            color: #28a745;
            margin: 10px 0;
            text-align: center;
        }}
        
        .features {{
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }}
        
        .features li {{
            padding: 8px 0;
            position: relative;
            padding-left: 25px;
        }}
        
        .features li::before {{
            content: "✓";
            position: absolute;
            left: 0;
            color: #667eea;
            font-weight: bold;
        }}
    </style>
</head>
<body>
    <div class="payment-container">
        <div class="header">
            <h1>File Organizer Premium</h1>
            <p>Upgrade to unlock advanced features</p>
        </div>
        
        <div class="plan-details">
            <h2>{plan_name}</h2>
            <div class="price">${amount/100:.2f}</div>
            <p class="description">{description}</p>
            
            <ul class="features">
                <li>Advanced file analysis and statistics</li>
                <li>Custom organization rules</li>
                <li>Export analysis reports</li>
                <li>Priority email support</li>
            </ul>
        </div>
        
        <form id="payment-form">
            <div id="card-element">
                <!-- Stripe Elements will create form elements here -->
            </div>
            
            <div id="error-message" class="error"></div>
            <div id="success-message" class="success"></div>
            
            <button id="submit-button" type="submit">
                Pay ${amount/100:.2f}
            </button>
        </form>
    </div>

    <script>
        const stripe = Stripe('{publishable_key}');
        const elements = stripe.elements();
        
        // Create card element
        const cardElement = elements.create('card', {{
            style: {{
                base: {{
                    fontSize: '16px',
                    color: '#424770',
                    '::placeholder': {{
                        color: '#aab7c4',
                    }},
                }},
            }}
        }});
        
        cardElement.mount('#card-element');
        
        // Handle form submission
        const form = document.getElementById('payment-form');
        const submitButton = document.getElementById('submit-button');
        const errorElement = document.getElementById('error-message');
        const successElement = document.getElementById('success-message');
        
        form.addEventListener('submit', async (event) => {{
            event.preventDefault();
            
            submitButton.disabled = true;
            submitButton.textContent = 'Processing...';
            errorElement.textContent = '';
            successElement.textContent = '';
            
            // Create payment intent on server (you would implement this endpoint)
            try {{
                const response = await fetch('/create-payment-intent', {{
                    method: 'POST',
                    headers: {{
                        'Content-Type': 'application/json',
                    }},
                    body: JSON.stringify({{
                        amount: {amount},
                        currency: 'usd',
                        description: '{description}'
                    }})
                }});
                
                const {{ client_secret }} = await response.json();
                
                // Confirm payment with Stripe
                const result = await stripe.confirmCardPayment(client_secret, {{
                    payment_method: {{
                        card: cardElement,
                    }}
                }});
                
                if (result.error) {{
                    errorElement.textContent = result.error.message;
                }} else {{
                    successElement.textContent = 'Payment successful! Thank you for your purchase.';
                    form.style.display = 'none';
                }}
            }} catch (error) {{
                errorElement.textContent = 'An error occurred. Please try again.';
            }}
            
            submitButton.disabled = false;
            submitButton.textContent = 'Pay ${amount/100:.2f}';
        }});
        
        // Handle real-time validation errors from the card Element
        cardElement.on('change', ({{error}}) => {{
            if (error) {{
                errorElement.textContent = error.message;
            }} else {{
                errorElement.textContent = '';
            }}
        }});
    </script>
</body>
</html>
"""
    
    return html_content

def main():
    """Demo of payment integration"""
    try:
        payment = StripePayment()
        
        print("File Organizer - Stripe Payment Integration")
        print("==========================================")
        
        # Demo plans
        plans = {
            'basic': {'name': 'Basic Plan', 'amount': 999, 'description': 'Basic premium features'},
            'pro': {'name': 'Pro Plan', 'amount': 1999, 'description': 'All premium features'}
        }
        
        print("\nAvailable plans:")
        for plan_id, plan in plans.items():
            print(f"- {plan['name']}: ${plan['amount']/100:.2f}")
        
        # Generate payment page for Pro plan
        html_content = generate_payment_page(
            plans['pro']['name'],
            plans['pro']['amount'],
            plans['pro']['description']
        )
        
        # Save payment page
        with open('payment.html', 'w') as f:
            f.write(html_content)
        
        print(f"\nPayment page generated: payment.html")
        print("Open this file in a browser to test the payment integration.")
        
        # Test creating a payment intent
        print("\nTesting payment intent creation...")
        result = payment.create_payment_intent(
            amount=plans['pro']['amount'],
            description=plans['pro']['description']
        )
        
        if result:
            print(f"✓ Payment intent created successfully")
            print(f"  ID: {result.get('id')}")
            print(f"  Status: {result.get('status')}")
            print(f"  Amount: ${result.get('amount', 0)/100:.2f}")
        else:
            print("✗ Failed to create payment intent")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__':
    main()