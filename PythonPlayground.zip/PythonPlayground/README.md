# File Organizer

A Python command-line tool for automatically organizing and managing files by type and custom rules.

## Features

- 🔍 **Directory Scanning**: Scan directories and subdirectories for files
- 📊 **File Statistics**: Display comprehensive file statistics and organization summary
- 🗂️ **Analysis and Planning**: Analyze files by type (images, documents, videos, etc.) and show organization suggestions
- ⚙️ **Configurable Rules**: Support custom file types and organization rules
- 📈 **Progress Indicators**: Visual progress bars for large operations
- 🌐 **Cross-platform**: Works on Windows, macOS, and Linux
- 📝 **Detailed Logging**: Operation tracking and error reporting

## Installation

1. Clone or download this repository
2. Install required dependencies:
   ```bash
   pip install rich
   ```

## Usage

### Scanning Directories

Scan a directory and display file statistics:

```bash
python file_organizer.py scan /path/to/directory
