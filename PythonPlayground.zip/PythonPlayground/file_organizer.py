#!/usr/bin/env python3
"""
File Organizer - A Python command-line tool for automatically organizing and managing files by type and custom rules.

This tool scans directories and subdirectories for files, organizes them by type (images, documents, videos, etc.),
displays file statistics and organization summary, and supports configurable organization rules.
"""

import os
import sys
import argparse
import logging
from pathlib import Path
from collections import defaultdict, Counter
from typing import Dict, List, Set, Tuple
import configparser
from datetime import datetime
import mimetypes

try:
    from rich.console import Console
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
    from rich.panel import Panel
    from rich.tree import Tree
    from rich.text import Text
    from rich.logging import RichHandler
except ImportError:
    print("Error: Rich library is required but not installed.")
    print("Please install it using: pip install rich")
    sys.exit(1)

# Initialize Rich console
console = Console()

class FileOrganizer:
    """Main class for file organization operations."""
    
    def __init__(self, config_path: str = "config.ini"):
        self.config_path = config_path
        self.config = configparser.ConfigParser()
        self.load_config()
        
        # File type mappings
        self.file_types = {
            'Images': {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.tif', '.svg', '.webp', '.ico', '.raw'},
            'Documents': {'.pdf', '.doc', '.docx', '.txt', '.rtf', '.odt', '.pages', '.tex', '.wpd'},
            'Spreadsheets': {'.xls', '.xlsx', '.csv', '.ods', '.numbers'},
            'Presentations': {'.ppt', '.pptx', '.odp', '.key'},
            'Videos': {'.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.m4v', '.3gp', '.mpg', '.mpeg'},
            'Audio': {'.mp3', '.wav', '.flac', '.aac', '.ogg', '.wma', '.m4a', '.opus'},
            'Archives': {'.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz', '.dmg', '.iso'},
            'Code': {'.py', '.js', '.html', '.css', '.java', '.cpp', '.c', '.h', '.php', '.rb', '.go', '.rs', '.swift'},
            'Executables': {'.exe', '.msi', '.deb', '.rpm', '.dmg', '.app', '.pkg'},
            'Fonts': {'.ttf', '.otf', '.woff', '.woff2', '.eot'}
        }
        
        # Load custom file types from config
        self.load_custom_file_types()
        
        # Setup logging
        self.setup_logging()
        
    def load_config(self):
        """Load configuration from file or create default config."""
        if os.path.exists(self.config_path):
            self.config.read(self.config_path)
        else:
            self.create_default_config()
            
    def create_default_config(self):
        """Create default configuration file."""
        self.config['DEFAULT'] = {
            'ignore_hidden_files': 'true',
            'ignore_system_files': 'true',
            'min_file_size': '0',
            'max_file_size': '0'
        }
        
        self.config['CustomFileTypes'] = {
            '# Add custom file types here': '# Example: MyType = .ext1,.ext2,.ext3'
        }
        
        self.config['IgnorePatterns'] = {
            'patterns': '.DS_Store,Thumbs.db,*.tmp,*.temp,__pycache__'
        }
        
        with open(self.config_path, 'w') as configfile:
            self.config.write(configfile)
            
    def load_custom_file_types(self):
        """Load custom file types from configuration."""
        if 'CustomFileTypes' in self.config:
            for key, value in self.config['CustomFileTypes'].items():
                if not key.startswith('#') and value and not value.startswith('#'):
                    extensions = {ext.strip() for ext in value.split(',')}
                    extensions = {ext if ext.startswith('.') else f'.{ext}' for ext in extensions}
                    self.file_types[key] = extensions
                    
    def setup_logging(self):
        """Setup logging configuration."""
        log_level = logging.INFO
        
        # Create logs directory if it doesn't exist
        os.makedirs('logs', exist_ok=True)
        
        # Setup file handler
        file_handler = logging.FileHandler(f'logs/file_organizer_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
        file_handler.setLevel(log_level)
        file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(file_formatter)
        
        # Setup rich handler for console
        rich_handler = RichHandler(console=console, rich_tracebacks=True)
        rich_handler.setLevel(log_level)
        
        # Configure logger
        logging.basicConfig(
            level=log_level,
            handlers=[file_handler, rich_handler],
            format='%(message)s'
        )
        
        self.logger = logging.getLogger(__name__)
        
    def should_ignore_file(self, file_path: Path) -> bool:
        """Check if file should be ignored based on configuration."""
        # Check if hidden files should be ignored
        if self.config.getboolean('DEFAULT', 'ignore_hidden_files', fallback=True):
            if file_path.name.startswith('.'):
                return True
                
        # Check ignore patterns
        ignore_patterns = self.config.get('IgnorePatterns', 'patterns', fallback='').split(',')
        for pattern in ignore_patterns:
            pattern = pattern.strip()
            if pattern and (file_path.name == pattern or file_path.match(pattern)):
                return True
                
        # Check file size limits
        try:
            file_size = file_path.stat().st_size
            min_size = self.config.getint('DEFAULT', 'min_file_size', fallback=0)
            max_size = self.config.getint('DEFAULT', 'max_file_size', fallback=0)
            
            if min_size > 0 and file_size < min_size:
                return True
            if max_size > 0 and file_size > max_size:
                return True
        except OSError:
            return True
            
        return False
        
    def get_file_type(self, file_path: Path) -> str:
        """Determine the type of a file based on its extension."""
        extension = file_path.suffix.lower()
        
        for file_type, extensions in self.file_types.items():
            if extension in extensions:
                return file_type
                
        return 'Other'
        
    def format_size(self, size_bytes: int) -> str:
        """Format file size in human readable format."""
        size = float(size_bytes)
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} PB"
        
    def scan_directory(self, directory: Path, recursive: bool = True) -> Dict:
        """Scan directory and collect file information."""
        files_by_type = defaultdict(list)
        total_files = 0
        total_size = 0
        errors = []
        
        try:
            # Count total files for progress bar
            all_files = []
            if recursive:
                all_files = list(directory.rglob('*'))
            else:
                all_files = list(directory.iterdir())
                
            file_count = sum(1 for f in all_files if f.is_file())
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                console=console
            ) as progress:
                
                task = progress.add_task(f"Scanning {directory}", total=file_count)
                
                for item in all_files:
                    try:
                        if item.is_file():
                            if self.should_ignore_file(item):
                                continue
                                
                            file_type = self.get_file_type(item)
                            file_size = item.stat().st_size
                            
                            files_by_type[file_type].append({
                                'path': item,
                                'size': file_size,
                                'modified': datetime.fromtimestamp(item.stat().st_mtime)
                            })
                            
                            total_files += 1
                            total_size += file_size
                            
                            progress.update(task, advance=1)
                            
                    except (OSError, PermissionError) as e:
                        errors.append(f"Error accessing {item}: {str(e)}")
                        continue
                        
        except (OSError, PermissionError) as e:
            errors.append(f"Error accessing directory {directory}: {str(e)}")
            
        return {
            'files_by_type': dict(files_by_type),
            'total_files': total_files,
            'total_size': total_size,
            'errors': errors
        }
        
    def display_statistics(self, scan_results: Dict):
        """Display file statistics in a formatted table."""
        files_by_type = scan_results['files_by_type']
        total_files = scan_results['total_files']
        total_size = scan_results['total_size']
        
        # Create summary table
        table = Table(title="File Organization Summary", show_header=True, header_style="bold magenta")
        table.add_column("File Type", style="cyan", no_wrap=True)
        table.add_column("Count", justify="right", style="green")
        table.add_column("Total Size", justify="right", style="yellow")
        table.add_column("Percentage", justify="right", style="blue")
        
        # Sort by file count (descending)
        sorted_types = sorted(files_by_type.items(), key=lambda x: len(x[1]), reverse=True)
        
        for file_type, files in sorted_types:
            count = len(files)
            type_size = sum(f['size'] for f in files)
            percentage = (count / total_files * 100) if total_files > 0 else 0
            
            table.add_row(
                file_type,
                str(count),
                self.format_size(type_size),
                f"{percentage:.1f}%"
            )
            
        console.print(table)
        
        # Display overall summary
        summary_panel = Panel(
            f"[bold]Total Files:[/bold] {total_files:,}\n"
            f"[bold]Total Size:[/bold] {self.format_size(total_size)}\n"
            f"[bold]File Types:[/bold] {len(files_by_type)}",
            title="Overall Summary",
            expand=False
        )
        console.print(summary_panel)
        
    def display_file_tree(self, scan_results: Dict, max_files_per_type: int = 5):
        """Display a tree view of files organized by type."""
        files_by_type = scan_results['files_by_type']
        
        tree = Tree("📁 File Organization Preview")
        
        for file_type, files in files_by_type.items():
            type_branch = tree.add(f"📂 {file_type} ({len(files)} files)")
            
            # Show first few files as examples
            for i, file_info in enumerate(files[:max_files_per_type]):
                file_path = file_info['path']
                file_size = self.format_size(file_info['size'])
                type_branch.add(f"📄 {file_path.name} ({file_size})")
                
            if len(files) > max_files_per_type:
                type_branch.add(f"... and {len(files) - max_files_per_type} more files")
                
        console.print(tree)
        
    def generate_organization_plan(self, scan_results: Dict, target_directory: Path) -> Dict:
        """Generate a plan for organizing files into target directory structure."""
        files_by_type = scan_results['files_by_type']
        organization_plan = {}
        
        for file_type, files in files_by_type.items():
            type_dir = target_directory / file_type
            organization_plan[file_type] = {
                'target_directory': type_dir,
                'files': files,
                'operations': []
            }
            
            for file_info in files:
                source_path = file_info['path']
                target_path = type_dir / source_path.name
                
                # Handle name conflicts
                counter = 1
                while target_path.exists():
                    name_parts = source_path.stem, counter, source_path.suffix
                    target_path = type_dir / f"{name_parts[0]}_{name_parts[1]}{name_parts[2]}"
                    counter += 1
                    
                organization_plan[file_type]['operations'].append({
                    'source': source_path,
                    'target': target_path,
                    'action': 'move'
                })
                
        return organization_plan
        
    def display_organization_plan(self, organization_plan: Dict):
        """Display the organization plan."""
        console.print("\n[bold]Organization Plan:[/bold]")
        
        for file_type, plan_info in organization_plan.items():
            target_dir = plan_info['target_directory']
            operations = plan_info['operations']
            
            if operations:
                console.print(f"\n[cyan]{file_type}[/cyan] → [yellow]{target_dir}[/yellow]")
                for i, op in enumerate(operations[:3]):  # Show first 3 operations
                    console.print(f"  • {op['source'].name}")
                    
                if len(operations) > 3:
                    console.print(f"  ... and {len(operations) - 3} more files")
                    
    def execute_organization_plan(self, organization_plan: Dict, dry_run: bool = True):
        """Display the organization plan (file moving functionality removed)."""
        console.print("\n[yellow]ANALYSIS MODE - This tool shows organization suggestions only[/yellow]")
        console.print("[dim]File moving functionality has been removed to focus on analysis and planning.[/dim]")
        
        total_files = sum(len(plan['operations']) for plan in organization_plan.values())
        console.print(f"\n[bold]Organization Summary:[/bold]")
        console.print(f"Total files analyzed: {total_files}")
        console.print(f"File types found: {len(organization_plan)}")
        
        self.display_organization_plan(organization_plan)

def main():
    """Main entry point for the file organizer."""
    parser = argparse.ArgumentParser(
        description="File Organizer - Automatically organize and manage files by type and custom rules",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s scan /path/to/directory                    # Scan directory and show statistics
  %(prog)s scan /path/to/directory --recursive        # Scan recursively (default)
  %(prog)s scan /path/to/directory --no-recursive     # Scan only top level
  %(prog)s organize /path/to/source /path/to/target   # Analyze and show organization plan
  %(prog)s config                                     # Show current configuration
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Scan command
    scan_parser = subparsers.add_parser('scan', help='Scan directory and show file statistics')
    scan_parser.add_argument('directory', type=Path, help='Directory to scan')
    scan_parser.add_argument('--recursive', action='store_true', default=True,
                           help='Scan subdirectories recursively (default)')
    scan_parser.add_argument('--no-recursive', dest='recursive', action='store_false',
                           help='Only scan top-level directory')
    scan_parser.add_argument('--tree', action='store_true',
                           help='Show file tree preview')
    scan_parser.add_argument('--config', default='config.ini',
                           help='Configuration file path (default: config.ini)')
    
    # Organize command
    org_parser = subparsers.add_parser('organize', help='Organize files into target directory')
    org_parser.add_argument('source', type=Path, help='Source directory to organize')
    org_parser.add_argument('target', type=Path, help='Target directory for organized files')

    org_parser.add_argument('--recursive', action='store_true', default=True,
                          help='Scan subdirectories recursively (default)')
    org_parser.add_argument('--no-recursive', dest='recursive', action='store_false',
                          help='Only scan top-level directory')
    org_parser.add_argument('--config', default='config.ini',
                          help='Configuration file path (default: config.ini)')
    
    # Config command
    config_parser = subparsers.add_parser('config', help='Show configuration information')
    config_parser.add_argument('--config', default='config.ini',
                             help='Configuration file path (default: config.ini)')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
        
    try:
        organizer = FileOrganizer(args.config)
        
        if args.command == 'scan':
            if not args.directory.exists():
                console.print(f"[red]Error: Directory '{args.directory}' does not exist.[/red]")
                return
                
            if not args.directory.is_dir():
                console.print(f"[red]Error: '{args.directory}' is not a directory.[/red]")
                return
                
            console.print(f"[green]Scanning directory: {args.directory}[/green]")
            scan_results = organizer.scan_directory(args.directory, args.recursive)
            
            if scan_results['errors']:
                console.print(f"\n[yellow]Warnings/Errors:[/yellow]")
                for error in scan_results['errors'][:5]:  # Show first 5 errors
                    console.print(f"  • {error}")
                if len(scan_results['errors']) > 5:
                    console.print(f"  ... and {len(scan_results['errors']) - 5} more errors")
                    
            organizer.display_statistics(scan_results)
            
            if args.tree:
                console.print("\n")
                organizer.display_file_tree(scan_results)
                
        elif args.command == 'organize':
            if not args.source.exists():
                console.print(f"[red]Error: Source directory '{args.source}' does not exist.[/red]")
                return
                
            console.print(f"[green]Scanning source directory: {args.source}[/green]")
            scan_results = organizer.scan_directory(args.source, args.recursive)
            
            if scan_results['total_files'] == 0:
                console.print("[yellow]No files found to organize.[/yellow]")
                return
                
            organizer.display_statistics(scan_results)
            
            console.print(f"\n[green]Generating organization plan for target: {args.target}[/green]")
            organization_plan = organizer.generate_organization_plan(scan_results, args.target)
            organizer.execute_organization_plan(organization_plan)
                    
        elif args.command == 'config':
            console.print(f"[green]Configuration file: {args.config}[/green]")
            
            if os.path.exists(args.config):
                with open(args.config, 'r') as f:
                    console.print("\n[cyan]Current configuration:[/cyan]")
                    console.print(f.read())
            else:
                console.print(f"[yellow]Configuration file not found. Creating default configuration.[/yellow]")
                temp_organizer = FileOrganizer(args.config)
                console.print(f"[green]Created default configuration at: {args.config}[/green]")
                
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled by user.[/yellow]")
    except Exception as e:
        console.print(f"[red]Unexpected error: {str(e)}[/red]")
        logging.exception("Unexpected error occurred")

if __name__ == '__main__':
    main()
