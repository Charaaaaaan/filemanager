#!/usr/bin/env python3
"""
Database Manager for File Organizer Premium Users
Handles user subscriptions and premium features
"""

import os
import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

class DatabaseManager:
    """Manages user subscriptions and premium features"""
    
    def __init__(self, db_path="file_organizer.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                stripe_customer_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create subscriptions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                plan_type TEXT NOT NULL,
                stripe_payment_id TEXT UNIQUE,
                amount INTEGER NOT NULL,
                status TEXT DEFAULT 'active',
                purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Create usage_logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS usage_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                action TEXT NOT NULL,
                details TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_user(self, email, stripe_customer_id=None):
        """Add a new user"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO users (email, stripe_customer_id)
                VALUES (?, ?)
            ''', (email, stripe_customer_id))
            user_id = cursor.lastrowid
            conn.commit()
            return user_id
        except sqlite3.IntegrityError:
            # User already exists
            cursor.execute('SELECT id FROM users WHERE email = ?', (email,))
            result = cursor.fetchone()
            return result[0] if result else None
        finally:
            conn.close()
    
    def add_subscription(self, user_id, plan_type, stripe_payment_id, amount):
        """Add a new subscription"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Calculate expiration (1 year from now for one-time purchase)
        expires_at = datetime.now() + timedelta(days=365)
        
        try:
            cursor.execute('''
                INSERT INTO subscriptions (user_id, plan_type, stripe_payment_id, amount, expires_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (user_id, plan_type, stripe_payment_id, amount, expires_at))
            subscription_id = cursor.lastrowid
            conn.commit()
            return subscription_id
        except sqlite3.IntegrityError:
            # Payment already processed
            return None
        finally:
            conn.close()
    
    def get_user_subscription(self, email):
        """Get user's active subscription"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT s.plan_type, s.status, s.purchased_at, s.expires_at
            FROM subscriptions s
            JOIN users u ON s.user_id = u.id
            WHERE u.email = ? AND s.status = 'active'
            ORDER BY s.purchased_at DESC
            LIMIT 1
        ''', (email,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'plan_type': result[0],
                'status': result[1],
                'purchased_at': result[2],
                'expires_at': result[3]
            }
        return None
    
    def check_premium_access(self, email):
        """Check if user has premium access"""
        subscription = self.get_user_subscription(email)
        
        if not subscription:
            return False
        
        # Check if subscription is still valid
        expires_at = datetime.fromisoformat(subscription['expires_at'])
        return datetime.now() < expires_at
    
    def log_usage(self, email, action, details=None):
        """Log user action"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get user ID
        cursor.execute('SELECT id FROM users WHERE email = ?', (email,))
        result = cursor.fetchone()
        user_id = result[0] if result else None
        
        cursor.execute('''
            INSERT INTO usage_logs (user_id, action, details)
            VALUES (?, ?, ?)
        ''', (user_id, action, json.dumps(details) if details else None))
        
        conn.commit()
        conn.close()
    
    def get_subscription_stats(self):
        """Get subscription statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total users
        cursor.execute('SELECT COUNT(*) FROM users')
        total_users = cursor.fetchone()[0]
        
        # Active subscriptions by plan
        cursor.execute('''
            SELECT plan_type, COUNT(*) 
            FROM subscriptions 
            WHERE status = 'active' 
            GROUP BY plan_type
        ''')
        subscriptions_by_plan = dict(cursor.fetchall())
        
        # Total revenue
        cursor.execute('''
            SELECT SUM(amount) 
            FROM subscriptions 
            WHERE status = 'active'
        ''')
        total_revenue = cursor.fetchone()[0] or 0
        
        conn.close()
        
        return {
            'total_users': total_users,
            'subscriptions_by_plan': subscriptions_by_plan,
            'total_revenue': total_revenue / 100  # Convert cents to dollars
        }

class PremiumFeatures:
    """Manages premium feature access"""
    
    def __init__(self):
        self.db = DatabaseManager()
    
    def require_premium(self, email):
        """Decorator to require premium access"""
        def decorator(func):
            def wrapper(*args, **kwargs):
                if not self.db.check_premium_access(email):
                    print("🔒 This feature requires a premium subscription.")
                    print("Visit http://localhost:5000 to upgrade your account.")
                    return None
                return func(*args, **kwargs)
            return wrapper
        return decorator
    
    def get_available_features(self, email):
        """Get list of available features for user"""
        subscription = self.db.get_user_subscription(email)
        
        if not subscription:
            return {
                'tier': 'free',
                'features': [
                    'Basic directory scanning',
                    'Simple file statistics',
                    'Basic organization planning'
                ]
            }
        
        plan_type = subscription['plan_type']
        
        if plan_type == 'basic':
            return {
                'tier': 'basic',
                'features': [
                    'Unlimited directory scans',
                    'Advanced file statistics',
                    'Custom organization rules',
                    'Export analysis reports'
                ]
            }
        elif plan_type == 'pro':
            return {
                'tier': 'pro',
                'features': [
                    'All Basic features',
                    'Bulk operations',
                    'Advanced filtering',
                    'Priority support',
                    'Custom file type definitions',
                    'API access'
                ]
            }
        
        return {'tier': 'free', 'features': []}

def demo_database():
    """Demonstrate database functionality"""
    db = DatabaseManager()
    premium = PremiumFeatures()
    
    print("File Organizer - Database Demo")
    print("=" * 40)
    
    # Demo user
    email = "demo@example.com"
    
    # Add user
    user_id = db.add_user(email, "cus_demo123")
    print(f"Added user: {email} (ID: {user_id})")
    
    # Check initial access
    print(f"Initial premium access: {db.check_premium_access(email)}")
    
    # Add subscription
    subscription_id = db.add_subscription(user_id, "pro", "pi_demo123", 1999)
    print(f"Added pro subscription (ID: {subscription_id})")
    
    # Check access after subscription
    print(f"Premium access after subscription: {db.check_premium_access(email)}")
    
    # Get user features
    features = premium.get_available_features(email)
    print(f"Available features: {features['tier']}")
    for feature in features['features']:
        print(f"  - {feature}")
    
    # Log some usage
    db.log_usage(email, "directory_scan", {"path": "/home/user/documents", "files_found": 1234})
    db.log_usage(email, "organization_plan", {"target": "/organized", "plan_generated": True})
    
    # Get stats
    stats = db.get_subscription_stats()
    print(f"\nSubscription Stats:")
    print(f"  Total users: {stats['total_users']}")
    print(f"  Subscriptions: {stats['subscriptions_by_plan']}")
    print(f"  Total revenue: ${stats['total_revenue']:.2f}")

if __name__ == '__main__':
    demo_database()