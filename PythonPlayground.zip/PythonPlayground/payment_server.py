#!/usr/bin/env python3
"""
Payment Server for File Organizer - Stripe Integration
Provides premium features through Stripe payments
"""

import os
import sys
from pathlib import Path

# Add current directory to Python path for imports
sys.path.insert(0, str(Path(__file__).parent))

# Try importing required packages - install them if missing
try:
    import stripe
except ImportError:
    print("Installing stripe...")
    os.system("pip install stripe")
    import stripe

try:
    from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
except ImportError:
    print("Installing flask...")
    os.system("pip install flask")
    from flask import Flask, render_template, request, redirect, url_for, flash, jsonify

from rich.console import Console

# Initialize console for rich output
console = Console()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY',
                                'dev-key-change-in-production')

# Configure Stripe
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')
STRIPE_PUBLISHABLE_KEY = os.environ.get('STRIPE_PUBLISHABLE_KEY')

if not stripe.api_key or not STRIPE_PUBLISHABLE_KEY:
    console.print(
        "[red]Error: Stripe API keys not found in environment variables.[/red]"
    )
    console.print(
        "Make sure STRIPE_SECRET_KEY and STRIPE_PUBLISHABLE_KEY are set.")
    sys.exit(1)

# Premium features pricing
PREMIUM_PLANS = {
    'basic': {
        'name':
        'File Organizer Basic',
        'price':
        50000,  # $500.00 in cents
        'features': [
            'Unlimited directory scans', 'Advanced file statistics',
            'Custom organization rules', 'Export analysis reports'
        ]
    },
    'pro': {
        'name':
        'File Organizer Pro',
        'price':
        20000,  # $200.00 in cents
        'features': [
            'All Basic features', 'Bulk operations', 'Advanced filtering',
            'Priority support', 'Custom file type definitions'
        ]
    }
}


@app.route('/')
def index():
    """Main page showing pricing plans"""
    return render_template('index.html',
                           plans=PREMIUM_PLANS,
                           stripe_pk=STRIPE_PUBLISHABLE_KEY)


@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    """Create Stripe checkout session"""
    try:
        plan_id = request.form.get('plan_id')

        if plan_id not in PREMIUM_PLANS:
            flash('Invalid plan selected', 'error')
            return redirect(url_for('index'))

        plan = PREMIUM_PLANS[plan_id]

        # Create Stripe checkout session
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name':
                        plan['name'],
                        'description':
                        f"Premium features for File Organizer - {plan['name']}"
                    },
                    'unit_amount': plan['price'],
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=url_for('success', _external=True) +
            '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=url_for('cancel', _external=True),
            metadata={
                'plan_id': plan_id,
                'plan_name': plan['name']
            })

        return redirect(checkout_session.url, code=303)

    except Exception as e:
        console.print(f"[red]Error creating checkout session: {e}[/red]")
        flash('Error processing payment. Please try again.', 'error')
        return redirect(url_for('index'))


@app.route('/success')
def success():
    """Payment success page"""
    session_id = request.args.get('session_id')

    if session_id:
        try:
            # Retrieve the checkout session
            session = stripe.checkout.Session.retrieve(session_id)
            plan_name = session.metadata.get('plan_name', 'Premium Plan')

            return render_template('success.html',
                                   plan_name=plan_name,
                                   session_id=session_id)
        except Exception as e:
            console.print(f"[red]Error retrieving session: {e}[/red]")
            flash('Error verifying payment', 'error')
            return redirect(url_for('index'))

    return render_template('success.html')


@app.route('/cancel')
def cancel():
    """Payment cancelled page"""
    return render_template('cancel.html')


@app.route('/webhook', methods=['POST'])
def stripe_webhook():
    """Handle Stripe webhooks"""
    payload = request.get_data(as_text=True)
    sig_header = request.headers.get('Stripe-Signature')

    try:
        # In production, you should set STRIPE_WEBHOOK_SECRET
        webhook_secret = os.environ.get('STRIPE_WEBHOOK_SECRET')

        if webhook_secret:
            event = stripe.Webhook.construct_event(payload, sig_header,
                                                   webhook_secret)
        else:
            # For development, just parse the event
            event = stripe.Event.construct_from(request.get_json(),
                                                stripe.api_key)

        # Handle the event
        if event['type'] == 'checkout.session.completed':
            session = event['data']['object']
            console.print(
                f"[green]Payment completed for session: {session['id']}[/green]"
            )

            # Here you would typically:
            # 1. Save the purchase to your database
            # 2. Send confirmation email
            # 3. Activate premium features for the user

        elif event['type'] == 'payment_intent.succeeded':
            payment_intent = event['data']['object']
            console.print(
                f"[green]Payment succeeded: {payment_intent['id']}[/green]")

        else:
            console.print(
                f"[yellow]Unhandled event type: {event['type']}[/yellow]")

        return jsonify({'status': 'success'})

    except ValueError as e:
        console.print(f"[red]Invalid payload: {e}[/red]")
        return jsonify({'error': 'Invalid payload'}), 400
    except Exception as e:
        console.print(f"[red]Invalid signature: {e}[/red]")
        return jsonify({'error': 'Invalid signature'}), 400


@app.route('/api/verify-payment/<session_id>')
def verify_payment(session_id):
    """API endpoint to verify payment status"""
    try:
        session = stripe.checkout.Session.retrieve(session_id)

        return jsonify({
            'payment_status':
            session.payment_status,
            'plan_id':
            session.metadata.get('plan_id'),
            'plan_name':
            session.metadata.get('plan_name'),
            'amount_total':
            session.amount_total,
            'customer_email':
            session.customer_details.email
            if session.customer_details else None
        })

    except Exception as e:
        console.print(f"[red]Error verifying payment: {e}[/red]")
        return jsonify({'error': 'Payment verification failed'}), 400


if __name__ == '__main__':
    # Create templates directory if it doesn't exist
    os.makedirs('templates', exist_ok=True)

    console.print("[green]Starting File Organizer Payment Server[/green]")
    console.print(f"Stripe Publishable Key: {STRIPE_PUBLISHABLE_KEY[:12]}...")
    console.print("Server will run on http://0.0.0.0:5000")

    app.run(host='0.0.0.0', port=5000, debug=True)
